module.exports = {
  base_url: "http://localhost:4005/",
  // APPLICATION_KEY: "2bb3c260-444a-4a73-81b5-d44ed441ce8c",
  // APPLICATION_SECRET: "4Hd96e/ykkKlV1IxjpZrTQ==",
  // APPLICATION_KEY: "d84a70dd-2a0f-4ea1-bdf3-3291398f657b",
  // APPLICATION_SECRET: "/QuQUcbAQUC4ucQ1SZz9ww==",
  APPLICATION_KEY: "12029b09-354b-4ffb-a90e-c78499dbf321",
  APPLICATION_SECRET: "pynLcnRbgEa5RKF0tfTZtQ==",
  fcm_serverKey:
    "AAAAwJkN2Cg:APA91bG7soLszsdtnVHIJDMmd1ELciI3OSki8hgNYzBGtosOu-A6QdLMVoE_lPW5Xh_DXD0PI81FtzyZjne_s_0yg8RXyJgazY4nu8UuMZ6Cz2e5s5_AeACIsRZUli9kdXJm8-whw8j3",
};
